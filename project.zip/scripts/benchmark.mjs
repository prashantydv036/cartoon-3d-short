// Benchmark: renders real frames of the bridge template with software WebGL (swangle) on a GitHub runner,
// times them, and writes out/report.md so we can decide if free GitHub rendering is fast enough.
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { bundle } from "@remotion/bundler";
import { ensureBrowser, renderMedia, renderStill, selectComposition } from "@remotion/renderer";

const FRAMES = [90, 700, 1300, 1900];   // hook, march, snap area, ending
const CLIP = [700, 729];                // 30 frames = 1 second, full size
const chromiumOptions = { gl: "swangle" };
const logs = [];
const onBrowserLog = (l) => { if (l.type === "error" || l.type === "warning") logs.push(`[${l.type}] ${l.text.slice(0, 200)}`); };
fs.mkdirSync("out", { recursive: true });

const rep = [];
const say = (s) => { console.log(s); rep.push(s); };
say(`# Render benchmark`);
say(`Machine: ${os.cpus().length} CPU cores (${os.cpus()[0]?.model}), ${(os.totalmem() / 2 ** 30).toFixed(1)} GB RAM`);

await ensureBrowser();
const t0 = Date.now();
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts"), publicDir: path.resolve("public") });
say(`Bundle: ${((Date.now() - t0) / 1000).toFixed(1)} s`);
const composition = await selectComposition({ serveUrl, id: "BridgeShort", chromiumOptions, onBrowserLog });

say(`\n## Stills at 1080x1920 (full size, all post effects on)`);
const stillTimes = [];
for (const f of FRAMES) {
  const out = `out/still_${f}.jpg`;
  const t = Date.now();
  try {
    await renderStill({ composition, serveUrl, frame: f, output: out, imageFormat: "jpeg", jpegQuality: 88,
      chromiumOptions, timeoutInMilliseconds: 900000, onBrowserLog });
    const s = (Date.now() - t) / 1000;
    const kb = Math.round(fs.statSync(out).size / 1024);
    stillTimes.push(s);
    say(`- frame ${f}: ${s.toFixed(1)} s, ${kb} KB${kb < 15 ? "  (WARNING: very small file, canvas may be blank)" : ""}`);
  } catch (e) { say(`- frame ${f}: FAILED ${String(e).slice(0, 300)}`); }
}

say(`\n## 1-second clip (frames ${CLIP[0]}-${CLIP[1]}) at 1080x1920`);
const c0 = Date.now();
try {
  await renderMedia({ composition, serveUrl, codec: "h264", crf: 18, outputLocation: "out/clip.mp4", frameRange: CLIP,
    chromiumOptions, concurrency: Math.max(1, os.cpus().length - 1), timeoutInMilliseconds: 900000, onBrowserLog });
  const s = (Date.now() - c0) / 1000;
  const per = s / (CLIP[1] - CLIP[0] + 1);
  say(`- clip time: ${s.toFixed(1)} s total, ${per.toFixed(2)} s per frame (parallel on this runner)`);
  const total = 1800;
  say(`\n## Estimate for a 60 s video (1800 frames) on this kind of runner`);
  say(`- one runner: ${(per * total / 3600).toFixed(1)} hours`);
  for (const n of [10, 20]) say(`- split across ${n} parallel runners: ${(per * total / n / 60).toFixed(0)} minutes each`);
} catch (e) { say(`- clip FAILED ${String(e).slice(0, 400)}`); }

if (logs.length) say(`\n## Browser warnings/errors (first 15)\n` + [...new Set(logs)].slice(0, 15).map((l) => `- ${l}`).join("\n"));
fs.writeFileSync("out/report.md", rep.join("\n") + "\n");
if (process.env.GITHUB_STEP_SUMMARY) fs.appendFileSync(process.env.GITHUB_STEP_SUMMARY, rep.join("\n") + "\n");
