# Cartoon 3D short: render benchmark
Real frames of the bridge template rendered with software WebGL on a GitHub runner, with timings.
